/* eslint-disable */

console.log('Hello from the client side!!!');
const locations = JSON.parse(document.getElementById('map').dataset.locations);
console.log(locations);
